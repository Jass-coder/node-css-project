const mongoose=require('../database')

var ordersSchema=new mongoose.Schema(
    {
        userId: [{type:mongoose.Schema.Types.ObjectId, ref:'User'}],
        product_id:[ {type:mongoose.Schema.Types.ObjectId, ref:'Product'}], 
        quantity: [{type:Number}],        
        dateOfOrder: {type:Date, default:new(Date)},
        process_status: {type:Boolean, default:false},
        deliveryStatus: {type:Boolean, default:false}
    });

const Order = mongoose.model('orders',ordersSchema);

module.exports = Order;
