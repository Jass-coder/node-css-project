const { isValidObjectId } = require("mongoose");
const mongoose = require("../database");


var departmentSchema = new mongoose.Schema({
    departmentId: {type:Number},
    departmentName: {type:String},
});



const Department = mongoose.model('departments', departmentSchema);

module.exports = Department;