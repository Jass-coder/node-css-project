var mongoose = require('../database')

var customerSchema = new mongoose.Schema(
    {
		userId: [{type:mongoose.Schema.Types.ObjectId, ref:"User"}],
        firstname:{type:String, require:true},
        lastname:{type:String, require:true},
        email:{type:String, require:true},
        phoneNumber:{type:String, require:true},
		street: {type:String, require:true},
        complement: {type:String},
        city: {type:String, require:true},
        state: {type:String, require:true},
        postCode: {type:String, require:true},
		payment_details:{type:String},		
    }
);
const Customer = mongoose.model('customer', customerSchema);

module.exports = Customer;