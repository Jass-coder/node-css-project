var mongoose = require('../database')

var productSchema = new mongoose.Schema(
    {
		categoryId: [{type:mongoose.Schema.Types.ObjectId, ref:"Category"}],
        productName:{type:String},
        productDescription:{type:String},
        productPrice:{type:mongoose.Schema.Types.Decimal128},
        productQuantity:{type:Number},	
    }
);
const Product = mongoose.model('product', productSchema);

module.exports = Product;