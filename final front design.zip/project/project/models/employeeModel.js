const { isValidObjectId } = require("mongoose");
const mongoose = require("../database");
const User = require("../models/userModel")

var employeeSchema = new mongoose.Schema({
    userId: [{type:mongoose.Schema.Types.ObjectId, ref:"User"}],
    firstname: {type:String, require:true},
    lastname: {type:String, require:true},
    dateOfBirth: {type:String, require:true},
    email: {type:String, require:true},
    phoneNumber:{type:String, require:true}, 
    street: {type:String, require:true},
    complement: {type:String},
    city: {type:String, require:true},
    state: {type:String, require:true},
    postCode: {type:String, require:true},
    dateHired: {type:String, require:true},
    departmentId: {type:Number},
    
    
});



const Employee = mongoose.model('employee', employeeSchema);

module.exports = Employee;

