var mongoose = require('../database')

var adminSchema = new mongoose.Schema(
    {
		userId: [{type:mongoose.Schema.Types.ObjectId, ref:"User"}],
        firstname:{type:String},
        lastname:{type:String},
        email:{type:String},
        phoneNumber:{type:String},	
    }
);
const Admin = mongoose.model('admin', adminSchema);

module.exports = Admin;