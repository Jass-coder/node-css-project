const mongoose = require("../database");
const bcrypt = require('bcryptjs');

var userSchema = new mongoose.Schema({
        username: {type:String, unique:true, require:true,},
        password: {type:String, require:true, select:false,},
        type:{type:String, default:"Customer"}, 

});

userSchema.pre('save', async function(next){
        const hash = await bcrypt.hash(this.password, 10);
        this.password = hash;

        next();
});

const User = mongoose.model('users', userSchema);

module.exports = User;