var mongoose = require('../database')

var cetegorySchema = new mongoose.Schema(
    {
        categoryName:{type:String}	
    }
);
const Category = mongoose.model('category', cetegorySchema);

module.exports = Category;