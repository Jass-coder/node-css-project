const express = require('express');

const Employee = require('../models/employeeModel');
const Department = require('../models/departmentModel')
const Product = require('../models/productModel')
const Order = require('../models/ordersModel')

module.exports={

    GetAllEmployees: function(req, res){
        Employee.find({},function(err,results){
            if (err) throw err;
            res.render('manageEmployees',{myemps:results});
        })
    },
    GetEmpById: async (req, res) => {
        Employee.find({_id:req.query.id}, async (err,results) =>{
            if (err) throw err;
            const depts = await Department.find({},function(err,results){
                if (err) throw err;
                return results;
            })
            res.render('updateEmployee',{myemployee:results, mydpts:depts});
        })
    },
    Employee: async (req, res) => {
        try{
            const employee = await Employee.findOne({ _id: req.query.id});
    
            res.render('employee', {emp:employee} );
            
        } catch (err){
            return res.status(400).send({error: 'Erro get employee page'});
        }
    },
    GetMyEmpById: async (req, res) => {
        Employee.find({_id:req.query.id}, async (err,results) =>{
            if (err) throw err;
            const depts = await Department.find({},function(err,results){
                if (err) throw err;
                return results;
            })
            const employee = await Employee.findOne({ _id: req.body.id});
            res.render('updateMyProfile',{emp:results, mydpts:depts});
        })
    },
    createEmp: async (req, res) => {
        try{
            const employee = await Employee.create(req.body);
            const orders = await Order.find({});
            const products = await Product.find({});
            res.render('employee', {emp:employee, orders:orders, myproducts:products} );
            
        } catch (err){
            return res.status(400).send({error: 'Registration failed'});
        }
    },
 
    deleteEmp:function(req,res){
        Employee.deleteOne({_id:req.query.id}).then(function(){
            res.redirect("/getEmps");
        }).catch(function(err){
            console.log("Error deleting data");
        })
    },
    updateEmp:function(req,res){
        Employee.updateOne({_id:req.body.id},
            {firstname:req.body.firstname, lastname:req.body.lastname, dateOfBirth:req.body.dateOfBirth, 
                email:req.body.email, phoneNumber:req.body.phoneNumber, street:req.body.street, complement:req.body.complement,
                city:req.body.city, state:req.body.state, postCode:req.body.postCode, dateHired:req.body.dateHired,
                departmentId:req.body.departmentId}, function(err, docs){
                if (err){console.log(err);}
                else{
                    res.redirect('/getEmps');
                }
            })
    },
    updateMyEmp: async (req, res) => {
        try{
            await Employee.updateOne({_id:req.body.id},
                {firstname:req.body.firstname, lastname:req.body.lastname, dateOfBirth:req.body.dateOfBirth, 
                    email:req.body.email, phoneNumber:req.body.phoneNumber, street:req.body.street, complement:req.body.complement,
                    city:req.body.city, state:req.body.state, postCode:req.body.postCode, dateHired:req.body.dateHired,
                    departmentId:req.body.departmentId});
            const orders = await Order.find({});
            const products = await Product.find({});
            const employee = await Employee.findOne({ _id: req.body.id});
            res.render('employee', {emp:employee, orders:orders, myproducts:products} );
            
        } catch (err){
            return res.status(400).send({error: 'Registration failed'});
        }
    },
}
