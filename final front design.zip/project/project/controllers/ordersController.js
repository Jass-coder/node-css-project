const express = require('express');
const Orders=require('../models/ordersModel')
const User = require('../models/userModel')
const Product = require('../models/productModel')
const Employee = require('../models/employeeModel');
const Customer = require('../models/customerModel')
const { escapeXML } = require('ejs');

module.exports={
GetAll: async (req, res) =>{
    try{
        const employee = await Employee.findOne({ _id: req.query.id});
        const products = await Product.find({});
        const orders = await Orders.find({});

        res.render('employee', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Erro get employee page'});
    }
},
GetProcessed: async (req, res) =>{
    try{
        const employee = await Employee.findOne({ _id: req.query.id});
        const products = await Product.find({});
        const orders = await Orders.find({process_status:true});
        

        res.render('processedOrders', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get orders.'});
    }
},
GetMyProcessed: async (req, res) =>{
    try{
        const customer = await Customer.findOne({ userId: req.query.id});
        const products = await Product.find({});
        const orders = await Orders.find({userId: req.query.id, process_status:true});

        res.render('myProcessedOrders', {customer:customer, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get orders.'});
    }
},
GetUnprocessed: async (req, res) =>{
    try{
        const employee = await Employee.findOne({ _id: req.query.id});
        const products = await Product.find({});
        const orders = await Orders.find({process_status:false});
        res.render('unprocessedOrders', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get orders.'});
    }
},
GetMyUnprocessed: async (req, res) =>{
    try{
        const customer = await Customer.findOne({ userId: req.query.id});
        const products = await Product.find({});
        const orders = await Orders.find({userId: req.query.id, process_status:false});

        res.render('myUnprocessedOrders', {customer:customer, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get orders.'});
    }
},
process: async (req, res) => {
    try{
        const par = req.query.id.split("/")
        orderId = par[0];
        empId = par[1];
        const employee = await Employee.findOne({ _id: empId});
        const products = await Product.find({});
        await Orders.updateOne({_id:orderId},
            {$set:{process_status:true,deliveryStatus:true}});
        const orders = await Orders.find({process_status:true});
        res.render('employee', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get pro orders.'});
    }
},
createOrder: async (req, res) => {
    try{
        const userId = req.body.userId;
        const customer = await Customer.findOne({userId:userId });
        await Orders.create(req.body);
        res.render('customer', {customer:customer});
        
    } catch (err){
        return res.status(400).send({error: 'Registration failed'});
    }
},
cancelOrder: async (req, res) =>{
    try{
        const myOrder = await Orders.findOne({ _id: req.query.id});
        const userId = myOrder.userId;
        
        const customer = await Customer.findOne({userId: userId});
        const products = await Product.find({});
        await Orders.deleteOne({_id: req.query.id});
        const orders = await Orders.find({userId: userId, process_status:false});

        res.render('myUnprocessedOrders', {customer:customer, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get orders.'});
    }
}, 
Order: async (req, res) => {
    try{
        const customerId = req.query.id;
        const customer = await Customer.findOne({_id:customerId });
        const prodts = await Product.find({});
        const userId = customer.userId[0]
        res.render('orders', {myuser:userId, customer:customer, myproducts:prodts});
        
    } catch (err){
        return res.status(400).send({error: 'Registration failed'});
    }
},
removeProcessedOrders: async (req, res) =>{
    try{
        const par = req.query.id.split("/")
        orderId = par[0];
        empId = par[1];
        const employee = await Employee.findOne({ _id: empId});
        const products = await Product.find({});
        await Orders.deleteOne({_id: orderId});
        const orders = await Orders.find({process_status:true});
        res.render('processedOrders', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get pro orders.'});
    }
},
removeUnprocessedOrders: async (req, res) =>{
    try{
        const par = req.query.id.split("/")
        orderId = par[0];
        empId = par[1];
        const employee = await Employee.findOne({ _id: empId});
        const products = await Product.find({});
        await Orders.deleteOne({_id: orderId});
        const orders = await Orders.find({process_status:false});
        res.render('unprocessedOrders', {emp:employee, orders:orders, myproducts:products} );
        
    } catch (err){
        return res.status(400).send({error: 'Error to get unp orders.'});
    }
}
}