const express = require('express');

const Customer = require('../models/customerModel');

module.exports={

    GetAllEmployees: function(req, res){
        Customer.find({},function(err,results){
            if (err) throw err;
            res.render('manageEmployees',{myemps:results});
        })
    },

    createCust: async (req, res) => {
        try{
            const customer = await Customer.create(req.body);
            res.render('customer', {customer:customer} );
            
        } catch (err){
            return res.status(400).send({error: 'Registration failed'});
        }
    },
    Customer: async (req, res) => {
        try{
            const customer = await Customer.findOne({ _id: req.query.id});
    
            res.render('customer', {customer:customer} );
            
        } catch (err){
            return res.status(400).send({error: 'Erro get employee page'});
        }
    },

    GetMyCustById: async (req, res) => {
        Customer.find({_id:req.query.id}, async (err,results) =>{
            if (err) throw err;
            res.render('updateCustomer',{customer:results});
        })
    },
    updateMyCust: async (req, res) => {
        try{
            await Customer.updateOne({_id:req.body.id},
                {firstname:req.body.firstname, lastname:req.body.lastname, email:req.body.email, phoneNumber:req.body.phoneNumber, 
                    street:req.body.street, complement:req.body.complement,
                    city:req.body.city, state:req.body.state, postCode:req.body.postCode, payment_details:req.body.payment_details});
            const customer = await Customer.findOne({ _id: req.body.id});
            res.render('customer', {customer:customer} );
            
        } catch (err){
            return res.status(400).send({error: 'Registration failed'});
        }
    },
}


