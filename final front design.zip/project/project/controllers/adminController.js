const express = require('express');

const Admin = require('../models/adminModel');


const router = express.Router();

router.post('/registerAdmin', async (req, res) => {
    try{
        await Admin.create(req.body);
        res.redirect('/admin');
        
    } catch (err){
        return res.status(400).send({error: 'Registration failed'});
    }
    
});

module.exports = app => app.use('/register', router);