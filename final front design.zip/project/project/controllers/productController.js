const express = require('express');

const Product = require('../models/productModel');

module.exports={

    GetAllProducts: function(req, res){
        Product.find({},function(err,results){
            if (err) throw err;
            res.render('stock',{myproducts:results});
        })
    },
    GetProducts: function(req, res){
        Product.find({},function(err,results){
            if (err) throw err;
            return results;
        })
    },
    GetProductById: function(req, res){
        Product.find({_id:req.query.id},function(err,results){
            if (err) throw err;
            res.render('updateProduct',{myproduct:results});
        })
    },
    create: function(req, res){
        Product.create(req.body,function(err, results){
            if (err){res.render("Error inserting data into categories collection")}; 
            res.redirect('/getstock')
        })
    },
 
    delete:function(req,res){
        Product.deleteOne({_id:req.query.id}).then(function(){
            res.redirect("/getstock");
        }).catch(function(err){
            console.log("Error deleting data");
        })
    },
    update:function(req,res){
        Product.updateOne({_id:req.body.id},
            {productName:req.body.productName, productDescription:req.body.productDescription, productPrice:req.body.productPrice, productQuantity:req.body.productQuantity}, function(err, docs){
                if (err){console.log(err);}
                else{
                    res.redirect('/getstock');
                }
            })
    }
}