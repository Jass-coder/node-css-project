const express = require('express');
const bcript = require('bcryptjs');
const jwt = require('jsonwebtoken');

const authConfig = require('../config/auth');

const User = require('../models/userModel');
const Order = require('../models/ordersModel')
const Department = require('../models/departmentModel')
const Product = require('../models/productModel')
const Employee = require('../models/employeeModel')
const Customer = require('../models/customerModel')

const router = express.Router();

function generateToken(params = {}) {
    return jwt.sign(params, authConfig.secret, {
        expiresIn: 86480,
    });
}

router.post('/register', async (req, res) => {
    const { username } = req.body;
    try{
        if (await User.findOne({ username }))
            return res.status(400).send({error: 'User already exist'});
        
        const user = await User.create(req.body);
        const orders = await Order.find({userId:req.body.id},function(err,results){
            if (err) throw err;
            return results;
        })
        const depts = await Department.find({},function(err,results){
            if (err) throw err;
            return results;
        })
        user.password = undefined;
        console.log(user.type);
        if (user.type === 'customer' || user.type === 'Customer')
            res.render('addCustomer', {myuser:user, myorders:orders} );
        else if(user.type === 'employee' || user.type === 'Employee')
            res.render('addEmployee', {myuser:user, mydpts:depts} );
        else
        res.render('addAdmin', {myuser:user} );
            return res.send({ 
                user,
                token : generateToken({id: user.id, type: user.type}),
            });
    } catch (err){
        return res.status(400).send({error: 'Registration failed'});
    }
    
});

router.post('/authenticate', async (req, res) => {
    const { username, password } = req.body;

    const user =  await User.findOne({ username }).select('+password');
    const orders = await Order.find({});
    const employee = await Employee.findOne({ userId: user.id });
    const customer = await Customer.findOne({ userId: user.id });
    const products = await Product.find({});
    
    if(!user)
        return res.status(400).send({error: 'User not found'});
    
    if (!await bcript.compare(password, user.password))
        return res.status(400).send({error: 'Invalid password'});

    user.password = undefined;
    if (user.type === 'customer' || user.type === 'Customer'){
        res.render('customer', {customer:customer} );
    }
    else if(user.type === 'employee' || user.type === 'Employee'){
        res.render('employee', {emp:employee, orders:orders, myproducts:products} );
    }
    else{
        res.render('admin', {myuser:user} );
    }
    return res.send({ 
        user,
        token : generateToken({id: user.id, type: user.type}),
    });
        
    
});


module.exports = app => app.use('/auth', router);