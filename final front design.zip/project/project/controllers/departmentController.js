const express = require('express');

const Department = require('../models/departmentModel');

module.exports={

    GetAllDepartments: function(req, res){
        Department.find({},function(err,results){
            if (err) throw err;
            res.render('departments',{mydepts:results});
        })
    },
    GetDeptById: async (req, res) => {
        Department.find({_id:req.query.id}, async (err,results) =>{
            if (err) throw err;
            res.render('updateDept',{mydpt:results});
        })
    },
    create: function(req, res){
        Department.create(req.body,function(err, results){
            if (err){res.render("Error inserting data into categories collection")}; 
            res.redirect('/getDepartments')
        })
    },
    deleteDep:function(req,res){
        Department.deleteOne({_id:req.query.id},function(err, results){
            if (err){res.render("Error inserting data into categories collection")}; 
            res.redirect('/getDepartments')
        });
    },
    update:function(req,res){
        Department.updateOne({_id:req.body.id},
            {departmentId:req.body.departmentId, departmentName:req.body.departmentName}, function(err, docs){
                if (err){console.log(err);}
                else{
                    res.redirect('/getDepartments');
                }
            })
    }
}
