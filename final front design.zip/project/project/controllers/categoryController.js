const express = require('express');

const Category = require('../models/categoryModel');

module.exports={

    GetAllCategories: function(req, res){
        Category.find({},function(err,results){
            if (err) throw err;
            res.render('addProduct',{mycategs:results});
        })
    },
    GetCategories: function(req, res){
        Category.find({},function(err,results){
            if (err) throw err;
            res.render('categories',{mycategs:results});
        })
    },
    create: function(req, res){
        Category.create(req.body,function(err, results){
            if (err){res.render("Error inserting data into categories collection")}; 
            res.redirect('/getCategories')
        })
    },
    deleteCat:function(req,res){
        Category.deleteOne({_id:req.query.id},function(err, results){
            if (err){res.render("Error inserting data into categories collection")}; 
            res.redirect('/getCategories')
        });
    },
}