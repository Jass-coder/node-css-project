const express = require('express');
const bodyParser = require('body-parser');
var path = require('path');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.set('view engine', 'ejs');
app.use(express.static('shared'));

require('./controllers/authController')(app);
require('./controllers/projectController')(app);
var employeecontroller = require('./controllers/employeeController');
var departmentcontroller = require('./controllers/departmentController');
var customercontroller = require('./controllers/customerController');
require('./controllers/adminController')(app);
var categorycontroller = require('./controllers/categoryController');
var productcontroller = require('./controllers/productController');
var orderController = require('./controllers/ordersController')

app.post('/register/registerCustomer', customercontroller.createCust)

app.get('/employee', employeecontroller.Employee)
app.get('/processedOrders', orderController.GetProcessed)
app.get('/unprocessedOrders', orderController.GetUnprocessed)
app.post('/register/registerOrder', orderController.createOrder)
app.get('/orders/process', orderController.process)
app.get('/delete/unprocessedOrders', orderController.removeUnprocessedOrders)
app.get('/delete/processedOrders', orderController.removeProcessedOrders)
app.get('/order/newOrder', orderController.Order)
app.get('/myProcessedOrders', orderController.GetMyProcessed)
app.get('/myUnprocessedOrders', orderController.GetMyUnprocessed)
app.get('/cancelOrders', orderController.cancelOrder)

app.post('/register/registerCategory', categorycontroller.create);
app.get('/addProduct', categorycontroller.GetAllCategories)
app.get('/getCategories', categorycontroller.GetCategories)
app.get('/category/delete', categorycontroller.deleteCat)

app.post('/register/registerProduct', productcontroller.create)
app.get('/getStock', productcontroller.GetAllProducts)
app.get('/products/delete', productcontroller.delete)
app.post('/update/updateProduct', productcontroller.update)
app.get('/products/update', productcontroller.GetProductById)

app.post('/register/registerEmployee', employeecontroller.createEmp)
app.get('/getEmps', employeecontroller.GetAllEmployees)
app.get('/employees/delete', employeecontroller.deleteEmp)
app.get('/employees/update', employeecontroller.GetEmpById)
app.post('/update/updateEmployee', employeecontroller.updateEmp)
app.get('/myemp/edit', employeecontroller.GetMyEmpById)
app.post('/myemployees/update', employeecontroller.updateMyEmp)

app.post('/register/addDeptment', departmentcontroller.create)
app.get('/getDepartments', departmentcontroller.GetAllDepartments)
app.get('/dept/delete', departmentcontroller.deleteDep)
app.get('/dept/update', departmentcontroller.GetDeptById)
app.post('/update/updateDepartment', departmentcontroller.update)

app.get('/customer', customercontroller.Customer)
app.get('/mycust/edit', customercontroller.GetMyCustById)
app.post('/updateMyCustomer', customercontroller.updateMyCust)

app.get('/', function(req, res){
    res.render('index');
});

app.get('/addUser', function(req, res){
    res.render('addUser');
});

app.get('/empProfile', function(req, res){
    res.render('empProfile');
});

app.get('/customer', function(req, res){
    res.render('customer');
});

app.get('/admin', function(req, res){
    res.render('admin');
});


app.listen(8081);